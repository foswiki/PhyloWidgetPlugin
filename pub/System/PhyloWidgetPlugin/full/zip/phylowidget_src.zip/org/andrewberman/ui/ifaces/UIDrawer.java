package org.andrewberman.ui.ifaces;

public class UIDrawer
{

}
